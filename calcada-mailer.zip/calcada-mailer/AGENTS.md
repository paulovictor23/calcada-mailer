# AGENTS.md

- Read server config only via `getEnv()` in src/lib/server-env.ts — Cloudflare Worker deploys (GitHub) expose secrets via Nitro's globalThis.__env__, not always on process.env.
- Login is a signed cookie session (ADMIN_EMAIL + ADMIN_PASSWORD secrets, SESSION_SECRET) — keeps the app free to host with no database; move to real user accounts when staff access opens.
- wrangler.jsonc `name` must match the Cloudflare Worker name and keeps `keep_vars: true` — so GitHub deploys hit the right Worker and don't wipe dashboard variables.
- Brand images live in public/ (not Lovable asset pointers) — asset-pointer URLs only resolve on Lovable hosting, not on Cloudflare.
