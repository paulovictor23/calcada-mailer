import { createFileRoute, redirect, useRouter } from "@tanstack/react-router";
import { useServerFn } from "@tanstack/react-start";
import { useState } from "react";
import { AlertTriangle, Lock } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { adminLogin, getAdminStatus } from "@/lib/admin.functions";

export const Route = createFileRoute("/login")({
  beforeLoad: async () => {
    const s = await getAdminStatus();
    if (s.admin) throw redirect({ to: "/" });
    return { missing: s.missing };
  },
  loader: ({ context }) => ({ missing: context.missing }),
  head: () => ({
    meta: [
      { title: "Acesso restrito — Calçada S.A." },
      { name: "description", content: "Acesso à Central de E-mail Marketing da Calçada S.A. com e-mail e senha." },
      { property: "og:title", content: "Acesso restrito — Calçada S.A." },
      { property: "og:description", content: "Acesso à Central de E-mail Marketing da Calçada S.A." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: LoginPage,
});

function LoginPage() {
  const router = useRouter();
  const { missing } = Route.useLoaderData();
  const login = useServerFn(adminLogin);
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError("");
    try {
      const r = await login({ data: { email, password } });
      if (r.ok) await router.navigate({ to: "/" });
      else setError("E-mail ou senha incorretos.");
    } catch (err) {
      setError(err instanceof Error ? err.message : "Erro ao entrar.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="flex min-h-screen items-center justify-center bg-background px-4">
      <div className="w-full max-w-sm rounded-lg border border-t-4 border-t-primary bg-card p-8 shadow-sm">
        <img src="/calcada-logo.webp" alt="Calçada S.A." className="mx-auto h-14 w-auto" />
        <p className="mt-4 text-center text-xs font-medium uppercase tracking-[0.14em] text-muted-foreground">
          Central de E-mail Marketing
        </p>

        {missing.length > 0 && (
          <div className="mt-6 rounded-md border border-destructive/40 bg-destructive/5 p-3 text-xs text-destructive">
            <div className="flex items-center gap-1.5 font-semibold">
              <AlertTriangle className="h-3.5 w-3.5" /> Configuração pendente no servidor
            </div>
            <p className="mt-1">Cadastre estas variáveis secretas na hospedagem:</p>
            <ul className="mt-1 list-disc pl-4 font-mono">
              {missing.map((m) => (
                <li key={m}>{m}</li>
              ))}
            </ul>
          </div>
        )}

        <form onSubmit={submit} className="mt-8 space-y-4">
          <div className="space-y-2">
            <Label htmlFor="email">E-mail</Label>
            <Input
              id="email"
              type="email"
              autoComplete="username"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="password">Senha</Label>
            <Input
              id="password"
              type="password"
              autoComplete="current-password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
            />
          </div>
          {error && <p className="text-sm text-destructive">{error}</p>}
          <Button type="submit" className="w-full" disabled={loading || !email || !password}>
            <Lock className="mr-2 h-4 w-4" /> {loading ? "Entrando…" : "Entrar"}
          </Button>
        </form>
      </div>
    </div>
  );
}
