import { createFileRoute, redirect, useRouter } from "@tanstack/react-router";
import { useServerFn } from "@tanstack/react-start";
import { adminLogout, getAdminStatus, sendEmail } from "@/lib/admin.functions";
import { useEffect, useMemo, useState } from "react";
import {
  Mail,
  Send,
  LogOut,
  Users,
  FileText,
  CheckCircle2,
  XCircle,
  Loader2,
  Save,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Checkbox } from "@/components/ui/checkbox";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Separator } from "@/components/ui/separator";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { ContactsTab } from "@/components/mailer/ContactsTab";
import { CampaignsTab } from "@/components/mailer/CampaignsTab";
import { EmailBuilder } from "@/components/mailer/EmailBuilder";
import {
  Campaign,
  ContactList,
  EMAIL_REGEX,
  campaignsStore,
  listsStore,
  uid,
} from "@/lib/mailer-storage";

export const Route = createFileRoute("/")({
  beforeLoad: async () => {
    const s = await getAdminStatus();
    if (!s.admin) throw redirect({ to: "/login" });
    return { resendConfigured: s.resendConfigured };
  },
  loader: ({ context }) => ({ resendConfigured: context.resendConfigured }),
  head: () => ({
    meta: [
      { title: "Central de E-mail Marketing — Calçada S.A." },
      { name: "description", content: "Listas de contatos, campanhas e disparos de e-mail da Calçada S.A." },
      { property: "og:title", content: "Central de E-mail Marketing — Calçada S.A." },
      { property: "og:description", content: "Listas de contatos, campanhas e disparos de e-mail da Calçada S.A." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: Index,
});

type LogStatus = "sending" | "success" | "error";
interface LogEntry {
  id: string;
  email: string;
  status: LogStatus;
  message?: string;
  timestamp: number;
}

function parseRecipients(raw: string): string[] {
  return Array.from(
    new Set(
      raw
        .split(/[\s,;]+/)
        .map((e) => e.trim().toLowerCase())
        .filter(Boolean),
    ),
  );
}

const sleep = (ms: number) => new Promise((r) => setTimeout(r, ms));

function Index() {
  const { resendConfigured } = Route.useLoaderData();
  const router = useRouter();
  const send = useServerFn(sendEmail);
  const logout = useServerFn(adminLogout);
  const [from, setFrom] = useState("");
  const [subject, setSubject] = useState("");
  const [body, setBody] = useState("");
  const [recipientsRaw, setRecipientsRaw] = useState("");
  const [intervalMs, setIntervalMs] = useState(600);
  const [logs, setLogs] = useState<LogEntry[]>([]);
  const [sending, setSending] = useState(false);
  const [tab, setTab] = useState("send");

  const [lists, setLists] = useState<ContactList[]>([]);
  const [campaigns, setCampaigns] = useState<Campaign[]>([]);
  const [selectedListIds, setSelectedListIds] = useState<string[]>([]);
  const [campaignName, setCampaignName] = useState("");
  const [editingCampaignId, setEditingCampaignId] = useState<string | null>(null);

  useEffect(() => {
    setLists(listsStore.get());
    setCampaigns(campaignsStore.get());
  }, []);

  const fromEmail = useMemo(() => {
    const m = from.trim().match(/<([^>]+)>\s*$/);
    return (m ? m[1] : from).trim();
  }, [from]);

  const manualRecipients = useMemo(() => parseRecipients(recipientsRaw), [recipientsRaw]);
  const listRecipients = useMemo(() => {
    const set = new Set<string>();
    for (const id of selectedListIds) {
      const l = lists.find((x) => x.id === id);
      if (l) l.contacts.forEach((c) => set.add(c));
    }
    return Array.from(set);
  }, [selectedListIds, lists]);

  const allRecipients = useMemo(
    () => Array.from(new Set([...listRecipients, ...manualRecipients])),
    [listRecipients, manualRecipients],
  );
  const validRecipients = useMemo(
    () => allRecipients.filter((e) => EMAIL_REGEX.test(e)),
    [allRecipients],
  );
  const invalidRecipients = useMemo(
    () => allRecipients.filter((e) => !EMAIL_REGEX.test(e)),
    [allRecipients],
  );

  const stats = useMemo(
    () => ({
      success: logs.filter((l) => l.status === "success").length,
      error: logs.filter((l) => l.status === "error").length,
      sending: logs.filter((l) => l.status === "sending").length,
    }),
    [logs],
  );

  const canSend =
    !sending &&
    resendConfigured &&
    EMAIL_REGEX.test(fromEmail) &&
    subject.trim().length > 0 &&
    body.trim().length > 0 &&
    validRecipients.length > 0;

  const updateLog = (id: string, patch: Partial<LogEntry>) =>
    setLogs((prev) => prev.map((l) => (l.id === id ? { ...l, ...patch } : l)));

  const handleSend = async () => {
    if (!canSend) return;
    setSending(true);
    setLogs([]);
    const isHtml = /<[a-z][\s\S]*>/i.test(body);

    for (const email of validRecipients) {
      const id = `${email}-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`;
      setLogs((prev) => [{ id, email, status: "sending", timestamp: Date.now() }, ...prev]);
      try {
        const data = await send({
          data: {
            from: from.trim(),
            to: email,
            subject: subject.trim(),
            ...(isHtml ? { html: body } : { text: body }),
          },
        });
        updateLog(id, { status: "success", message: data?.id ? `ID: ${data.id}` : "Enviado" });
      } catch (err) {
        const message = err instanceof Error ? err.message : "Erro desconhecido";
        updateLog(id, { status: "error", message });
      }
      if (intervalMs > 0) await sleep(intervalMs);
    }
    setSending(false);
  };

  const saveCampaign = () => {
    const name = campaignName.trim() || subject.trim() || "Sem nome";
    const now = Date.now();
    let next: Campaign[];
    if (editingCampaignId) {
      next = campaigns.map((c) =>
        c.id === editingCampaignId
          ? { ...c, name, from, subject, body, listIds: selectedListIds, updatedAt: now }
          : c,
      );
    } else {
      next = [
        ...campaigns,
        {
          id: uid(),
          name,
          from,
          subject,
          body,
          listIds: selectedListIds,
          createdAt: now,
          updatedAt: now,
        },
      ];
    }
    campaignsStore.set(next);
    setCampaigns(next);
    setEditingCampaignId(next[next.length - 1]?.id ?? editingCampaignId);
  };

  const loadCampaign = (c: Campaign) => {
    setFrom(c.from);
    setSubject(c.subject);
    setBody(c.body);
    setSelectedListIds(c.listIds);
    setCampaignName(c.name);
    setEditingCampaignId(c.id);
    setTab("send");
  };

  const toggleList = (id: string) =>
    setSelectedListIds((prev) =>
      prev.includes(id) ? prev.filter((x) => x !== id) : [...prev, id],
    );

  return (
    <div className="min-h-screen bg-background">
      <header className="border-b border-t-4 border-t-primary bg-card shadow-sm">
        <div className="mx-auto flex max-w-6xl items-center gap-5 px-6 py-4">
          <img src="/calcada-logo.webp" alt="Calçada S.A. — A arte de construir" className="h-11 w-auto" />
          <div className="hidden h-8 w-px bg-border sm:block" />
          <span className="hidden text-sm font-medium uppercase tracking-[0.14em] text-muted-foreground sm:block">
            Central de E-mail Marketing
          </span>
          <Button
            variant="ghost"
            size="sm"
            className="ml-auto"
            onClick={async () => {
              await logout();
              await router.navigate({ to: "/login" });
            }}
          >
            <LogOut className="mr-2 h-4 w-4" /> Sair
          </Button>
        </div>
      </header>

      <main className="mx-auto max-w-6xl px-6 py-8">
        {!resendConfigured && (
          <div className="mb-6 rounded-md border border-primary/40 bg-accent px-4 py-3 text-sm text-accent-foreground">
            A chave do Resend ainda não foi configurada no painel. Os disparos ficam bloqueados até lá.
          </div>
        )}
        <Tabs value={tab} onValueChange={setTab} className="space-y-6">
          <TabsList className="grid w-full grid-cols-3 sm:w-auto">
            <TabsTrigger value="send">Disparo</TabsTrigger>
            <TabsTrigger value="contacts">Contatos</TabsTrigger>
            <TabsTrigger value="campaigns">Campanhas</TabsTrigger>
          </TabsList>

          <TabsContent value="send" className="space-y-6">
            <div className="grid gap-6 lg:grid-cols-[minmax(0,1fr)_280px]">
              <div className="space-y-6">
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2 text-base">
                      <FileText className="h-4 w-4" /> E-mail
                    </CardTitle>
                    <CardDescription>
                      O remetente precisa pertencer a um domínio verificado no Resend.
                    </CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="grid gap-4 sm:grid-cols-2">
                      <div className="space-y-2">
                        <Label htmlFor="from">Remetente</Label>
                        <Input
                          id="from"
                          placeholder="Nome <noreply@seu-dominio.com>"
                          value={from}
                          onChange={(e) => setFrom(e.target.value)}
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="interval">Intervalo entre envios (ms)</Label>
                        <Input
                          id="interval"
                          type="number"
                          min={0}
                          step={100}
                          value={intervalMs}
                          onChange={(e) =>
                            setIntervalMs(Math.max(0, Number(e.target.value) || 0))
                          }
                        />
                      </div>
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="subject">Assunto</Label>
                      <Input
                        id="subject"
                        placeholder="Novidades da semana 🚀"
                        value={subject}
                        onChange={(e) => setSubject(e.target.value)}
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="body">Corpo do e-mail (texto ou HTML)</Label>
                      <Tabs defaultValue="edit" className="w-full">
                        <TabsList className="grid w-full grid-cols-3">
                          <TabsTrigger value="edit">Editar</TabsTrigger>
                          <TabsTrigger value="builder">Editor visual</TabsTrigger>
                          <TabsTrigger value="preview">Pré-visualizar</TabsTrigger>
                        </TabsList>
                        <TabsContent value="edit" className="mt-3">
                          <Textarea
                            id="body"
                            placeholder={"<h1>Olá!</h1>\n<p>Conteúdo do seu e-mail...</p>"}
                            value={body}
                            onChange={(e) => setBody(e.target.value)}
                            className="min-h-[240px] font-mono text-sm"
                          />
                          <p className="mt-2 text-xs text-muted-foreground">
                            HTML é detectado automaticamente quando há tags como &lt;p&gt;,
                            &lt;a&gt;, etc.
                          </p>
                        </TabsContent>
                        <TabsContent value="builder" className="mt-3">
                          <EmailBuilder onApply={(html) => setBody(html)} />
                        </TabsContent>
                        <TabsContent value="preview" className="mt-3">
                          <div className="rounded-md border bg-white">
                            <div className="flex items-center justify-between border-b px-3 py-2 text-xs text-muted-foreground">
                              <span className="truncate">
                                <strong className="text-foreground">De:</strong> {from || "—"}
                              </span>
                              <span className="truncate">
                                <strong className="text-foreground">Assunto:</strong>{" "}
                                {subject || "—"}
                              </span>
                            </div>
                            {body.trim() ? (
                              /<[a-z][\s\S]*>/i.test(body) ? (
                                <iframe
                                  title="Pré-visualização do e-mail"
                                  sandbox=""
                                  srcDoc={body}
                                  className="h-[320px] w-full rounded-b-md bg-white"
                                />
                              ) : (
                                <pre className="max-h-[320px] overflow-auto whitespace-pre-wrap p-4 font-sans text-sm text-foreground">
                                  {body}
                                </pre>
                              )
                            ) : (
                              <div className="flex h-[320px] items-center justify-center text-sm text-muted-foreground">
                                Escreva algo no editor para ver a pré-visualização.
                              </div>
                            )}
                          </div>
                        </TabsContent>
                      </Tabs>
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2 text-base">
                      <Users className="h-4 w-4" /> Destinatários
                    </CardTitle>
                    <CardDescription>
                      Selecione listas salvas e/ou cole e-mails avulsos.
                    </CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    {lists.length === 0 && (
                      <p className="rounded-md border border-dashed p-3 text-xs text-muted-foreground">
                        Nenhuma lista salva ainda. Crie listas na aba “Contatos” para
                        enviar para elas junto com os e-mails avulsos.
                      </p>
                    )}
                    {lists.length > 0 && (
                      <div className="space-y-2">
                        <Label>Listas salvas</Label>
                        <div className="grid gap-2 rounded-md border p-3 sm:grid-cols-2">
                          {lists.map((l) => (
                            <label
                              key={l.id}
                              className="flex cursor-pointer items-center gap-2 text-sm"
                            >
                              <Checkbox
                                checked={selectedListIds.includes(l.id)}
                                onCheckedChange={() => toggleList(l.id)}
                              />
                              <span className="min-w-0 flex-1 truncate">
                                <span className="font-medium">{l.name}</span>{" "}
                                <span className="text-xs text-muted-foreground">
                                  ({l.contacts.length}) · {l.group}
                                </span>
                              </span>
                            </label>
                          ))}
                        </div>
                      </div>
                    )}

                    <div className="space-y-2">
                      <Label htmlFor="manual-recipients">E-mails avulsos</Label>
                      <Textarea
                        id="manual-recipients"
                        placeholder={"alice@exemplo.com, bob@exemplo.com"}
                        value={recipientsRaw}
                        onChange={(e) => setRecipientsRaw(e.target.value)}
                        className="min-h-[100px] font-mono text-sm"
                      />
                    </div>

                    <div className="flex flex-wrap items-center gap-2 text-xs">
                      <Badge variant="secondary">{validRecipients.length} válidos</Badge>
                      {invalidRecipients.length > 0 && (
                        <Badge variant="destructive">
                          {invalidRecipients.length} inválidos
                        </Badge>
                      )}
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2 text-base">
                      <Save className="h-4 w-4" /> Campanha
                    </CardTitle>
                    <CardDescription>
                      Salve a configuração atual para reutilizar depois.
                    </CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-3">
                    <div className="grid gap-3 sm:grid-cols-[1fr_auto]">
                      <Input
                        placeholder="Nome da campanha"
                        value={campaignName}
                        onChange={(e) => setCampaignName(e.target.value)}
                      />
                      <Button variant="outline" onClick={saveCampaign}>
                        <Save className="mr-2 h-4 w-4" />
                        {editingCampaignId ? "Atualizar" : "Salvar campanha"}
                      </Button>
                    </div>
                    {editingCampaignId && (
                      <p className="text-xs text-muted-foreground">
                        Editando campanha existente.{" "}
                        <button
                          className="underline"
                          onClick={() => {
                            setEditingCampaignId(null);
                            setCampaignName("");
                          }}
                        >
                          Criar nova
                        </button>
                      </p>
                    )}
                  </CardContent>
                </Card>

                <Button onClick={handleSend} disabled={!canSend} size="lg" className="w-full">
                  {sending ? (
                    <>
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                      Enviando {stats.success + stats.error + 1}/{validRecipients.length}…
                    </>
                  ) : (
                    <>
                      <Send className="mr-2 h-4 w-4" />
                      Disparar para {validRecipients.length} destinatário(s)
                    </>
                  )}
                </Button>
              </div>

              <aside className="lg:sticky lg:top-6 lg:self-start">
                <Card className="h-full">
                  <CardHeader>
                    <CardTitle className="text-base">Log de envios</CardTitle>
                    <CardDescription>Status em tempo real.</CardDescription>
                    <div className="flex gap-2 pt-2">
                      <Badge variant="outline" className="gap-1">
                        <CheckCircle2 className="h-3 w-3 text-emerald-600" />
                        {stats.success}
                      </Badge>
                      <Badge variant="outline" className="gap-1">
                        <XCircle className="h-3 w-3 text-destructive" />
                        {stats.error}
                      </Badge>
                      <Badge variant="outline" className="gap-1">
                        <Loader2 className="h-3 w-3" />
                        {stats.sending}
                      </Badge>
                    </div>
                  </CardHeader>
                  <Separator />
                  <CardContent className="p-0">
                    <ScrollArea className="h-[520px]">
                      {logs.length === 0 ? (
                        <div className="flex h-[520px] flex-col items-center justify-center gap-2 px-6 text-center text-sm text-muted-foreground">
                          <Mail className="h-8 w-8 opacity-30" />
                          <p>Nenhum envio ainda.</p>
                        </div>
                      ) : (
                        <ul className="divide-y">
                          {logs.map((log) => (
                            <li
                              key={log.id}
                              className="flex items-start gap-3 px-4 py-3 text-sm"
                            >
                              <StatusIcon status={log.status} />
                              <div className="min-w-0 flex-1">
                                <p className="truncate font-medium">{log.email}</p>
                                {log.message && (
                                  <p className="truncate text-xs text-muted-foreground">
                                    {log.message}
                                  </p>
                                )}
                              </div>
                              <span className="shrink-0 text-xs text-muted-foreground">
                                {new Date(log.timestamp).toLocaleTimeString()}
                              </span>
                            </li>
                          ))}
                        </ul>
                      )}
                    </ScrollArea>
                  </CardContent>
                </Card>
              </aside>
            </div>
          </TabsContent>

          <TabsContent value="contacts">
            <ContactsTab lists={lists} onChange={setLists} />
          </TabsContent>

          <TabsContent value="campaigns">
            <CampaignsTab
              campaigns={campaigns}
              lists={lists}
              onChange={setCampaigns}
              onLoad={loadCampaign}
              onSend={(c) => {
                loadCampaign(c);
                setTimeout(() => handleSend(), 50);
              }}
            />
          </TabsContent>
        </Tabs>
      </main>
    </div>
  );
}

function StatusIcon({ status }: { status: LogStatus }) {
  if (status === "sending")
    return <Loader2 className="mt-0.5 h-4 w-4 shrink-0 animate-spin text-muted-foreground" />;
  if (status === "success")
    return <CheckCircle2 className="mt-0.5 h-4 w-4 shrink-0 text-emerald-600" />;
  return <XCircle className="mt-0.5 h-4 w-4 shrink-0 text-destructive" />;
}
