import { Megaphone, Trash2, Send, Pencil } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Campaign, ContactList, campaignsStore } from "@/lib/mailer-storage";

interface Props {
  campaigns: Campaign[];
  lists: ContactList[];
  onChange: (c: Campaign[]) => void;
  onLoad: (c: Campaign) => void;
  onSend: (c: Campaign) => void;
}

export function CampaignsTab({ campaigns, lists, onChange, onLoad, onSend }: Props) {
  const remove = (id: string) => {
    const next = campaigns.filter((c) => c.id !== id);
    campaignsStore.set(next);
    onChange(next);
  };

  const totalContacts = (c: Campaign) =>
    Array.from(
      new Set(
        c.listIds
          .flatMap((id) => lists.find((l) => l.id === id)?.contacts ?? [])
      ),
    ).length;

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2 text-base">
          <Megaphone className="h-4 w-4" /> Campanhas salvas
        </CardTitle>
        <CardDescription>
          Configure e salve uma campanha na aba “Disparo” para reutilizar depois.
        </CardDescription>
      </CardHeader>
      <CardContent>
        {campaigns.length === 0 ? (
          <p className="py-12 text-center text-sm text-muted-foreground">
            Nenhuma campanha salva ainda.
          </p>
        ) : (
          <ul className="divide-y rounded-md border">
            {campaigns.map((c) => (
              <li key={c.id} className="flex flex-wrap items-center gap-3 px-4 py-3">
                <div className="min-w-0 flex-1">
                  <p className="truncate font-medium">{c.name}</p>
                  <p className="truncate text-xs text-muted-foreground">
                    {c.subject || "(sem assunto)"} • atualizada{" "}
                    {new Date(c.updatedAt).toLocaleString()}
                  </p>
                  <div className="mt-1 flex flex-wrap gap-1">
                    <Badge variant="secondary">{totalContacts(c)} contatos</Badge>
                    {c.listIds.map((id) => {
                      const l = lists.find((x) => x.id === id);
                      return (
                        <Badge key={id} variant="outline">
                          {l ? l.name : "lista removida"}
                        </Badge>
                      );
                    })}
                  </div>
                </div>
                <div className="flex gap-1">
                  <Button size="sm" variant="outline" onClick={() => onLoad(c)}>
                    <Pencil className="mr-1 h-3 w-3" /> Editar
                  </Button>
                  <Button size="sm" onClick={() => onSend(c)}>
                    <Send className="mr-1 h-3 w-3" /> Enviar
                  </Button>
                  <Button
                    size="icon"
                    variant="ghost"
                    onClick={() => remove(c.id)}
                    aria-label="Excluir campanha"
                  >
                    <Trash2 className="h-4 w-4 text-destructive" />
                  </Button>
                </div>
              </li>
            ))}
          </ul>
        )}
      </CardContent>
    </Card>
  );
}
