import { useRef, useState } from "react";
import * as XLSX from "xlsx";
import { Upload, Trash2, Users, FileSpreadsheet } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import {
  ContactList,
  EMAIL_REGEX,
  extractEmailsFromRows,
  listsStore,
  uid,
} from "@/lib/mailer-storage";

interface Props {
  lists: ContactList[];
  onChange: (lists: ContactList[]) => void;
}

export function ContactsTab({ lists, onChange }: Props) {
  const fileRef = useRef<HTMLInputElement>(null);
  const [name, setName] = useState("");
  const [group, setGroup] = useState("");
  const [manual, setManual] = useState("");
  const [parsed, setParsed] = useState<string[]>([]);
  const [fileName, setFileName] = useState("");

  const handleFile = async (file: File) => {
    setFileName(file.name);
    const buf = await file.arrayBuffer();
    const wb = XLSX.read(buf, { type: "array" });
    const all: string[] = [];
    for (const sheetName of wb.SheetNames) {
      const rows = XLSX.utils.sheet_to_json<unknown[]>(wb.Sheets[sheetName], {
        header: 1,
        blankrows: false,
      });
      all.push(...extractEmailsFromRows(rows));
    }
    setParsed(Array.from(new Set(all)));
  };

  const manualEmails = manual
    .split(/[\s,;]+/)
    .map((e) => e.trim().toLowerCase())
    .filter((e) => EMAIL_REGEX.test(e));

  const finalEmails = Array.from(new Set([...parsed, ...manualEmails]));

  const reset = () => {
    setName("");
    setGroup("");
    setManual("");
    setParsed([]);
    setFileName("");
    if (fileRef.current) fileRef.current.value = "";
  };

  const save = () => {
    if (!name.trim() || finalEmails.length === 0) return;
    const next: ContactList[] = [
      ...lists,
      {
        id: uid(),
        name: name.trim(),
        group: group.trim() || "Sem grupo",
        contacts: finalEmails,
        createdAt: Date.now(),
      },
    ];
    listsStore.set(next);
    onChange(next);
    reset();
  };

  const remove = (id: string) => {
    const next = lists.filter((l) => l.id !== id);
    listsStore.set(next);
    onChange(next);
  };

  const grouped = lists.reduce<Record<string, ContactList[]>>((acc, l) => {
    (acc[l.group] ||= []).push(l);
    return acc;
  }, {});

  return (
    <div className="grid gap-6 lg:grid-cols-[1fr_1fr]">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-base">
            <Upload className="h-4 w-4" /> Nova lista de contatos
          </CardTitle>
          <CardDescription>
            Importe um CSV/Excel ou cole os e-mails manualmente.
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid gap-3 sm:grid-cols-2">
            <div className="space-y-2">
              <Label htmlFor="list-name">Nome da lista</Label>
              <Input
                id="list-name"
                placeholder="Clientes Black Friday"
                value={name}
                onChange={(e) => setName(e.target.value)}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="list-group">Grupo</Label>
              <Input
                id="list-group"
                placeholder="Clientes, Leads, Newsletter…"
                value={group}
                onChange={(e) => setGroup(e.target.value)}
              />
            </div>
          </div>

          <div className="space-y-2">
            <Label>Arquivo (.csv, .xlsx, .xls)</Label>
            <div className="flex items-center gap-2">
              <Input
                ref={fileRef}
                type="file"
                accept=".csv,.xlsx,.xls,text/csv"
                onChange={(e) => {
                  const f = e.target.files?.[0];
                  if (f) handleFile(f);
                }}
              />
            </div>
            {fileName && (
              <p className="flex items-center gap-1 text-xs text-muted-foreground">
                <FileSpreadsheet className="h-3 w-3" />
                {fileName} — {parsed.length} e-mails detectados
              </p>
            )}
            <p className="text-xs text-muted-foreground">
              Lemos todas as colunas e extraímos automaticamente o que parece e-mail.
            </p>
          </div>

          <div className="space-y-2">
            <Label htmlFor="manual">Adicionar manualmente</Label>
            <Textarea
              id="manual"
              placeholder={"alice@exemplo.com, bob@exemplo.com"}
              value={manual}
              onChange={(e) => setManual(e.target.value)}
              className="min-h-[80px] font-mono text-sm"
            />
          </div>

          <div className="flex items-center justify-between">
            <Badge variant="secondary">{finalEmails.length} contatos</Badge>
            <div className="flex gap-2">
              <Button variant="ghost" onClick={reset}>
                Limpar
              </Button>
              <Button onClick={save} disabled={!name.trim() || finalEmails.length === 0}>
                Salvar lista
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-base">
            <Users className="h-4 w-4" /> Listas salvas
          </CardTitle>
          <CardDescription>
            {lists.length} lista(s) — {lists.reduce((s, l) => s + l.contacts.length, 0)} contatos.
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          {lists.length === 0 ? (
            <p className="py-8 text-center text-sm text-muted-foreground">
              Nenhuma lista ainda.
            </p>
          ) : (
            Object.entries(grouped).map(([g, items]) => (
              <div key={g} className="space-y-2">
                <h4 className="text-xs font-semibold uppercase tracking-wide text-muted-foreground">
                  {g}
                </h4>
                <ul className="divide-y rounded-md border">
                  {items.map((l) => (
                    <li
                      key={l.id}
                      className="flex items-center justify-between gap-2 px-3 py-2 text-sm"
                    >
                      <div className="min-w-0">
                        <p className="truncate font-medium">{l.name}</p>
                        <p className="text-xs text-muted-foreground">
                          {l.contacts.length} contatos •{" "}
                          {new Date(l.createdAt).toLocaleDateString()}
                        </p>
                      </div>
                      <Button
                        size="icon"
                        variant="ghost"
                        onClick={() => remove(l.id)}
                        aria-label="Excluir lista"
                      >
                        <Trash2 className="h-4 w-4 text-destructive" />
                      </Button>
                    </li>
                  ))}
                </ul>
              </div>
            ))
          )}
        </CardContent>
      </Card>
    </div>
  );
}
