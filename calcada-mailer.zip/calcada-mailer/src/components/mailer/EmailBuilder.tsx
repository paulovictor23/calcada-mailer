import { useEffect, useMemo, useRef, useState } from "react";
import {
  ArrowDown,
  ArrowUp,
  Image as ImageIcon,
  Link2,
  Plus,
  Trash2,
  Type,
  MousePointerClick,
  PanelTop,
  PanelBottom,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

type BlockType = "header-image" | "text" | "image" | "button" | "footer-image";

interface BaseBlock {
  id: string;
  type: BlockType;
}
interface ImageBlock extends BaseBlock {
  type: "header-image" | "image" | "footer-image";
  src: string;
  alt: string;
  href?: string;
  width: number; // percent
}
interface TextBlock extends BaseBlock {
  type: "text";
  text: string;
  fontFamily: string;
  fontSize: number;
  color: string;
  align: "left" | "center" | "right";
  bold: boolean;
  italic: boolean;
  href?: string;
}
interface ButtonBlock extends BaseBlock {
  type: "button";
  label: string;
  href: string;
  bg: string;
  color: string;
  align: "left" | "center" | "right";
}
type Block = ImageBlock | TextBlock | ButtonBlock;

const uid = () => Math.random().toString(36).slice(2, 10);

const FONT_FAMILIES = [
  "Arial, Helvetica, sans-serif",
  "'Helvetica Neue', Helvetica, Arial, sans-serif",
  "Georgia, 'Times New Roman', serif",
  "'Times New Roman', Times, serif",
  "'Trebuchet MS', sans-serif",
  "Verdana, Geneva, sans-serif",
  "'Courier New', Courier, monospace",
];

function fileToDataUrl(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const r = new FileReader();
    r.onload = () => resolve(String(r.result));
    r.onerror = reject;
    r.readAsDataURL(file);
  });
}

function escapeHtml(s: string) {
  return s
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;");
}

function renderBlock(b: Block): string {
  if (b.type === "text") {
    const style = [
      `font-family:${b.fontFamily}`,
      `font-size:${b.fontSize}px`,
      `color:${b.color}`,
      `text-align:${b.align}`,
      `line-height:1.5`,
      `margin:0 0 16px 0`,
      b.bold ? "font-weight:bold" : "",
      b.italic ? "font-style:italic" : "",
    ]
      .filter(Boolean)
      .join(";");
    const inner = escapeHtml(b.text).replace(/\n/g, "<br/>");
    const content = b.href
      ? `<a href="${escapeHtml(b.href)}" style="color:${b.color};text-decoration:underline">${inner}</a>`
      : inner;
    return `<p style="${style}">${content}</p>`;
  }
  if (b.type === "button") {
    const align = b.align;
    return `<table role="presentation" cellpadding="0" cellspacing="0" border="0" width="100%" style="margin:8px 0 16px 0"><tr><td align="${align}"><a href="${escapeHtml(
      b.href || "#",
    )}" style="background:${b.bg};color:${b.color};padding:12px 22px;border-radius:6px;text-decoration:none;display:inline-block;font-family:Arial,sans-serif;font-size:15px;font-weight:600">${escapeHtml(
      b.label,
    )}</a></td></tr></table>`;
  }
  // image variants
  const img = `<img src="${b.src}" alt="${escapeHtml(b.alt || "")}" style="display:block;width:${b.width}%;max-width:100%;height:auto;border:0;margin:${
    b.type === "header-image" ? "0 auto 16px" : b.type === "footer-image" ? "16px auto 0" : "8px auto"
  }" />`;
  const wrapped = b.href
    ? `<a href="${escapeHtml(b.href)}" style="text-decoration:none">${img}</a>`
    : img;
  return `<div style="text-align:center">${wrapped}</div>`;
}

export function buildHtml(blocks: Block[]): string {
  const body = blocks.map(renderBlock).join("\n");
  return `<!doctype html>
<html><head><meta charset="utf-8"/><meta name="viewport" content="width=device-width,initial-scale=1"/></head>
<body style="margin:0;padding:0;background:#f5f5f5">
  <table role="presentation" width="100%" cellpadding="0" cellspacing="0" border="0" style="background:#f5f5f5;padding:24px 0">
    <tr><td align="center">
      <table role="presentation" width="600" cellpadding="0" cellspacing="0" border="0" style="background:#ffffff;max-width:600px;width:100%;padding:24px;border-radius:8px">
        <tr><td>
${body}
        </td></tr>
      </table>
    </td></tr>
  </table>
</body></html>`;
}

interface Props {
  onApply: (html: string) => void;
}

export function EmailBuilder({ onApply }: Props) {
  const [blocks, setBlocks] = useState<Block[]>([]);
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const fileInputs = useRef<Record<string, HTMLInputElement | null>>({});

  const html = useMemo(() => buildHtml(blocks), [blocks]);
  const selected = blocks.find((b) => b.id === selectedId) || null;

  useEffect(() => {
    if (!selectedId && blocks.length) setSelectedId(blocks[0].id);
  }, [blocks, selectedId]);

  const update = <T extends Block>(id: string, patch: Partial<T>) =>
    setBlocks((prev) => prev.map((b) => (b.id === id ? ({ ...b, ...patch } as Block) : b)));
  const remove = (id: string) =>
    setBlocks((prev) => prev.filter((b) => b.id !== id));
  const move = (id: string, dir: -1 | 1) =>
    setBlocks((prev) => {
      const i = prev.findIndex((b) => b.id === id);
      if (i < 0) return prev;
      const j = i + dir;
      if (j < 0 || j >= prev.length) return prev;
      const next = [...prev];
      [next[i], next[j]] = [next[j], next[i]];
      return next;
    });

  const add = (type: BlockType) => {
    const id = uid();
    let nb: Block;
    if (type === "text") {
      nb = {
        id,
        type,
        text: "Escreva seu texto aqui...",
        fontFamily: FONT_FAMILIES[0],
        fontSize: 16,
        color: "#222222",
        align: "left",
        bold: false,
        italic: false,
      };
    } else if (type === "button") {
      nb = {
        id,
        type,
        label: "Clique aqui",
        href: "https://",
        bg: "#2563eb",
        color: "#ffffff",
        align: "center",
      };
    } else {
      nb = { id, type, src: "", alt: "", width: 100 };
    }
    setBlocks((p) => [...p, nb]);
    setSelectedId(id);
  };

  const handleUpload = async (id: string, file?: File | null) => {
    if (!file) return;
    const dataUrl = await fileToDataUrl(file);
    update(id, { src: dataUrl } as Partial<ImageBlock>);
  };

  return (
    <div className="space-y-4">
      {/* Preview on top, full width */}
      <div className="rounded-md border bg-white">
        <div className="flex items-center justify-between border-b px-3 py-2 text-xs text-muted-foreground">
          <span>Pré-visualização</span>
          <button
            type="button"
            className="text-xs text-primary hover:underline disabled:opacity-50"
            disabled={blocks.length === 0}
            onClick={() => {
              const w = window.open("", "_blank");
              if (w) {
                w.document.open();
                w.document.write(html);
                w.document.close();
              }
            }}
          >
            Abrir em nova aba
          </button>
        </div>
        {blocks.length === 0 ? (
          <div className="flex h-[320px] items-center justify-center text-sm text-muted-foreground">
            Adicione blocos para começar.
          </div>
        ) : (
          <iframe
            title="Editor preview"
            sandbox=""
            srcDoc={html}
            className="h-[520px] w-full rounded-b-md bg-white"
          />
        )}
      </div>

      <div className="grid gap-4 md:grid-cols-[260px_1fr]">
      {/* Blocks list */}
      <div className="space-y-3">
        <div className="rounded-md border p-2">
          <p className="mb-2 px-1 text-xs font-medium text-muted-foreground">Adicionar bloco</p>
          <div className="grid grid-cols-2 gap-1">
            <Button size="sm" variant="outline" onClick={() => add("header-image")}>
              <PanelTop className="mr-1 h-3.5 w-3.5" /> Topo
            </Button>
            <Button size="sm" variant="outline" onClick={() => add("text")}>
              <Type className="mr-1 h-3.5 w-3.5" /> Texto
            </Button>
            <Button size="sm" variant="outline" onClick={() => add("image")}>
              <ImageIcon className="mr-1 h-3.5 w-3.5" /> Imagem
            </Button>
            <Button size="sm" variant="outline" onClick={() => add("button")}>
              <MousePointerClick className="mr-1 h-3.5 w-3.5" /> Botão
            </Button>
            <Button size="sm" variant="outline" className="col-span-2" onClick={() => add("footer-image")}>
              <PanelBottom className="mr-1 h-3.5 w-3.5" /> Rodapé
            </Button>
          </div>
        </div>

        <div className="rounded-md border">
          <p className="border-b px-3 py-2 text-xs font-medium text-muted-foreground">
            Estrutura ({blocks.length})
          </p>
          {blocks.length === 0 ? (
            <p className="p-3 text-xs text-muted-foreground">Adicione blocos acima.</p>
          ) : (
            <ul className="divide-y">
              {blocks.map((b, idx) => (
                <li
                  key={b.id}
                  className={`flex items-center gap-1 px-2 py-1.5 text-sm ${
                    selectedId === b.id ? "bg-accent" : ""
                  }`}
                >
                  <button
                    className="min-w-0 flex-1 truncate text-left"
                    onClick={() => setSelectedId(b.id)}
                  >
                    {idx + 1}. {labelFor(b.type)}
                  </button>
                  <Button size="icon" variant="ghost" className="h-6 w-6" onClick={() => move(b.id, -1)}>
                    <ArrowUp className="h-3 w-3" />
                  </Button>
                  <Button size="icon" variant="ghost" className="h-6 w-6" onClick={() => move(b.id, 1)}>
                    <ArrowDown className="h-3 w-3" />
                  </Button>
                  <Button
                    size="icon"
                    variant="ghost"
                    className="h-6 w-6 text-destructive"
                    onClick={() => remove(b.id)}
                  >
                    <Trash2 className="h-3 w-3" />
                  </Button>
                </li>
              ))}
            </ul>
          )}
        </div>

        <Button
          className="w-full"
          onClick={() => onApply(html)}
          disabled={blocks.length === 0}
        >
          <Plus className="mr-2 h-4 w-4" />
          Aplicar ao corpo do e-mail
        </Button>
      </div>


      {/* Inspector */}
      <div className="rounded-md border p-3">
        <p className="mb-3 text-xs font-medium text-muted-foreground">Propriedades</p>
        {!selected ? (
          <p className="text-xs text-muted-foreground">Selecione um bloco.</p>
        ) : selected.type === "text" ? (
          <div className="space-y-3">
            <div className="space-y-1.5">
              <Label className="text-xs">Texto</Label>
              <Textarea
                value={selected.text}
                onChange={(e) => update(selected.id, { text: e.target.value })}
                className="min-h-[100px]"
              />
            </div>
            <div className="space-y-1.5">
              <Label className="text-xs">Fonte</Label>
              <Select
                value={selected.fontFamily}
                onValueChange={(v) => update(selected.id, { fontFamily: v })}
              >
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  {FONT_FAMILIES.map((f) => (
                    <SelectItem key={f} value={f}>{f.split(",")[0].replace(/'/g, "")}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="grid grid-cols-2 gap-2">
              <div className="space-y-1.5">
                <Label className="text-xs">Tamanho (px)</Label>
                <Input
                  type="number"
                  min={8}
                  max={72}
                  value={selected.fontSize}
                  onChange={(e) => update(selected.id, { fontSize: Number(e.target.value) || 16 })}
                />
              </div>
              <div className="space-y-1.5">
                <Label className="text-xs">Cor</Label>
                <Input
                  type="color"
                  value={selected.color}
                  onChange={(e) => update(selected.id, { color: e.target.value })}
                  className="h-9 p-1"
                />
              </div>
            </div>
            <div className="space-y-1.5">
              <Label className="text-xs">Alinhamento</Label>
              <Select
                value={selected.align}
                onValueChange={(v) => update(selected.id, { align: v as TextBlock["align"] })}
              >
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="left">Esquerda</SelectItem>
                  <SelectItem value="center">Centro</SelectItem>
                  <SelectItem value="right">Direita</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="flex gap-2">
              <Button
                size="sm"
                variant={selected.bold ? "default" : "outline"}
                onClick={() => update(selected.id, { bold: !selected.bold })}
              >
                Negrito
              </Button>
              <Button
                size="sm"
                variant={selected.italic ? "default" : "outline"}
                onClick={() => update(selected.id, { italic: !selected.italic })}
              >
                Itálico
              </Button>
            </div>
            <div className="space-y-1.5">
              <Label className="text-xs flex items-center gap-1"><Link2 className="h-3 w-3" /> Link (opcional)</Label>
              <Input
                placeholder="https://"
                value={selected.href || ""}
                onChange={(e) => update(selected.id, { href: e.target.value })}
              />
            </div>
          </div>
        ) : selected.type === "button" ? (
          <div className="space-y-3">
            <div className="space-y-1.5">
              <Label className="text-xs">Texto do botão</Label>
              <Input
                value={selected.label}
                onChange={(e) => update(selected.id, { label: e.target.value })}
              />
            </div>
            <div className="space-y-1.5">
              <Label className="text-xs">Link</Label>
              <Input
                value={selected.href}
                onChange={(e) => update(selected.id, { href: e.target.value })}
              />
            </div>
            <div className="grid grid-cols-2 gap-2">
              <div className="space-y-1.5">
                <Label className="text-xs">Fundo</Label>
                <Input type="color" className="h-9 p-1" value={selected.bg}
                  onChange={(e) => update(selected.id, { bg: e.target.value })} />
              </div>
              <div className="space-y-1.5">
                <Label className="text-xs">Texto</Label>
                <Input type="color" className="h-9 p-1" value={selected.color}
                  onChange={(e) => update(selected.id, { color: e.target.value })} />
              </div>
            </div>
            <div className="space-y-1.5">
              <Label className="text-xs">Alinhamento</Label>
              <Select
                value={selected.align}
                onValueChange={(v) => update(selected.id, { align: v as ButtonBlock["align"] })}
              >
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="left">Esquerda</SelectItem>
                  <SelectItem value="center">Centro</SelectItem>
                  <SelectItem value="right">Direita</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
        ) : (
          <div className="space-y-3">
            <div className="space-y-1.5">
              <Label className="text-xs">Imagem</Label>
              <input
                ref={(el) => {
                  fileInputs.current[selected.id] = el;
                }}
                type="file"
                accept="image/*"
                className="hidden"
                onChange={(e) => handleUpload(selected.id, e.target.files?.[0])}
              />
              <Button
                variant="outline"
                size="sm"
                className="w-full"
                onClick={() => fileInputs.current[selected.id]?.click()}
              >
                <ImageIcon className="mr-2 h-4 w-4" />
                {selected.src ? "Trocar imagem" : "Fazer upload"}
              </Button>
              {selected.src && (
                <img
                  src={selected.src}
                  alt=""
                  className="mt-2 max-h-32 w-full rounded border object-contain"
                />
              )}
              <p className="text-[10px] text-muted-foreground">
                A imagem é embutida no e-mail (base64). Para envios em massa, prefira hospedar e usar a URL pública.
              </p>
            </div>
            <div className="space-y-1.5">
              <Label className="text-xs">Ou URL da imagem</Label>
              <Input
                placeholder="https://..."
                value={selected.src.startsWith("data:") ? "" : selected.src}
                onChange={(e) => update(selected.id, { src: e.target.value } as Partial<ImageBlock>)}
              />
            </div>
            <div className="space-y-1.5">
              <Label className="text-xs">Texto alternativo</Label>
              <Input
                value={selected.alt}
                onChange={(e) => update(selected.id, { alt: e.target.value } as Partial<ImageBlock>)}
              />
            </div>
            <div className="space-y-1.5">
              <Label className="text-xs">Largura (%)</Label>
              <Input
                type="number"
                min={10}
                max={100}
                value={selected.width}
                onChange={(e) =>
                  update(selected.id, { width: Math.min(100, Math.max(10, Number(e.target.value) || 100)) } as Partial<ImageBlock>)
                }
              />
            </div>
            <div className="space-y-1.5">
              <Label className="text-xs flex items-center gap-1"><Link2 className="h-3 w-3" /> Link (opcional)</Label>
              <Input
                placeholder="https://"
                value={selected.href || ""}
                onChange={(e) => update(selected.id, { href: e.target.value } as Partial<ImageBlock>)}
              />
            </div>
          </div>
        )}
      </div>
      </div>
    </div>
  );
}

function labelFor(t: BlockType) {
  switch (t) {
    case "header-image": return "Imagem de topo";
    case "footer-image": return "Imagem de rodapé";
    case "image": return "Imagem";
    case "text": return "Texto";
    case "button": return "Botão";
  }
}
