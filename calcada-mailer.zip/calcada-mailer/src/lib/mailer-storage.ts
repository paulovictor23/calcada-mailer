export interface ContactList {
  id: string;
  name: string;
  group: string;
  contacts: string[];
  createdAt: number;
}

export interface Campaign {
  id: string;
  name: string;
  from: string;
  subject: string;
  body: string;
  listIds: string[];
  createdAt: number;
  updatedAt: number;
}

const LISTS_KEY = "mailer.lists.v1";
const CAMPAIGNS_KEY = "mailer.campaigns.v1";

function read<T>(key: string, fallback: T): T {
  if (typeof window === "undefined") return fallback;
  try {
    const raw = localStorage.getItem(key);
    return raw ? (JSON.parse(raw) as T) : fallback;
  } catch {
    return fallback;
  }
}

function write<T>(key: string, value: T) {
  if (typeof window === "undefined") return;
  localStorage.setItem(key, JSON.stringify(value));
}

export const listsStore = {
  get: () => read<ContactList[]>(LISTS_KEY, []),
  set: (v: ContactList[]) => write(LISTS_KEY, v),
};

export const campaignsStore = {
  get: () => read<Campaign[]>(CAMPAIGNS_KEY, []),
  set: (v: Campaign[]) => write(CAMPAIGNS_KEY, v),
};

export const EMAIL_REGEX = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

export function uid() {
  return `${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 8)}`;
}

export function extractEmailsFromRows(rows: unknown[][]): string[] {
  const found = new Set<string>();
  for (const row of rows) {
    for (const cell of row) {
      if (cell == null) continue;
      const s = String(cell);
      const matches = s.match(/[^\s,;<>"']+@[^\s,;<>"']+\.[^\s,;<>"']+/g);
      if (matches) {
        for (const m of matches) {
          const e = m.toLowerCase().trim();
          if (EMAIL_REGEX.test(e)) found.add(e);
        }
      }
    }
  }
  return Array.from(found);
}
