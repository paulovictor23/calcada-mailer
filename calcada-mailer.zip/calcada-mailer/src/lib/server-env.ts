// Reads server configuration from:
// - process.env (Lovable hosting / Node dev)
// - globalThis.__env__ (Cloudflare Worker bindings, set by Nitro's cloudflare-module handler)
// - globalThis.__CF_ENV (fallback captured in src/server.ts)
export function getEnv(name: string): string | undefined {
  const fromProcess = typeof process !== "undefined" ? process.env?.[name] : undefined;
  if (fromProcess) return fromProcess;
  const g = globalThis as { __env__?: Record<string, unknown>; __CF_ENV?: Record<string, unknown> };
  for (const src of [g.__env__, g.__CF_ENV]) {
    const v = src?.[name];
    if (typeof v === "string" && v) return v;
  }
  return undefined;
}

export const REQUIRED_ENV = ["SESSION_SECRET", "ADMIN_EMAIL", "ADMIN_PASSWORD", "RESEND_API_KEY"] as const;

export function missingEnv(): string[] {
  return REQUIRED_ENV.filter((n) => !getEnv(n));
}
