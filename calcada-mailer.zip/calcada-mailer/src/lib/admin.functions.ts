import { createServerFn } from "@tanstack/react-start";
import { useSession } from "@tanstack/react-start/server";
import { z } from "zod";
import { getEnv, missingEnv } from "./server-env";

type AdminSession = { admin?: boolean; email?: string };

function sessionConfig() {
  const password = getEnv("SESSION_SECRET");
  if (!password) throw new Error("SESSION_SECRET não configurado no servidor");
  if (password.length < 32) throw new Error("SESSION_SECRET precisa ter pelo menos 32 caracteres");
  return {
    password,
    name: "calcada-admin",
    maxAge: 60 * 60 * 12,
    // "none" so the session also works inside the Lovable preview frame
    cookie: { httpOnly: true, secure: true, sameSite: "none" as const, path: "/" },
  };
}

async function digest(s: string) {
  return new Uint8Array(await crypto.subtle.digest("SHA-256", new TextEncoder().encode(s)));
}

async function safeEqual(a: string, b: string) {
  const [x, y] = await Promise.all([digest(a), digest(b)]);
  let diff = 0;
  for (let i = 0; i < x.length; i++) diff |= x[i] ^ y[i];
  return diff === 0;
}

async function requireAdmin() {
  const session = await useSession<AdminSession>(sessionConfig());
  if (!session.data.admin) throw new Error("Não autorizado. Faça login novamente.");
}

export const getAdminStatus = createServerFn({ method: "GET" }).handler(async () => {
  const missing = missingEnv();
  if (missing.includes("SESSION_SECRET")) {
    return { admin: false, email: null, resendConfigured: !!getEnv("RESEND_API_KEY"), missing };
  }
  try {
    const session = await useSession<AdminSession>(sessionConfig());
    return {
      admin: !!session.data.admin,
      email: session.data.email ?? null,
      resendConfigured: !!getEnv("RESEND_API_KEY"),
      missing,
    };
  } catch (e) {
    return {
      admin: false,
      email: null,
      resendConfigured: !!getEnv("RESEND_API_KEY"),
      missing: [...missing, e instanceof Error ? e.message : "Erro de sessão"],
    };
  }
});

export const adminLogin = createServerFn({ method: "POST" })
  .inputValidator((d: unknown) =>
    z
      .object({ email: z.string().trim().email().max(320), password: z.string().min(1).max(200) })
      .parse(d),
  )
  .handler(async ({ data }) => {
    const expectedEmail = getEnv("ADMIN_EMAIL");
    const expectedPassword = getEnv("ADMIN_PASSWORD");
    if (!expectedEmail || !expectedPassword) {
      throw new Error("Login não configurado no servidor (ADMIN_EMAIL / ADMIN_PASSWORD).");
    }
    const [emailOk, passOk] = await Promise.all([
      safeEqual(data.email.trim().toLowerCase(), expectedEmail.trim().toLowerCase()),
      safeEqual(data.password.trim(), expectedPassword.trim()),
    ]);
    if (!emailOk || !passOk) return { ok: false as const };
    const session = await useSession<AdminSession>(sessionConfig());
    await session.update({ admin: true, email: expectedEmail.trim().toLowerCase() });
    return { ok: true as const };
  });

export const adminLogout = createServerFn({ method: "POST" }).handler(async () => {
  const session = await useSession<AdminSession>(sessionConfig());
  await session.clear();
  return { ok: true as const };
});

const sendSchema = z.object({
  from: z.string().min(3).max(320),
  to: z.string().email().max(320),
  subject: z.string().min(1).max(998),
  html: z.string().max(5_000_000).optional(),
  text: z.string().max(5_000_000).optional(),
});

export const sendEmail = createServerFn({ method: "POST" })
  .inputValidator((d: unknown) => sendSchema.parse(d))
  .handler(async ({ data }) => {
    await requireAdmin();
    const key = getEnv("RESEND_API_KEY");
    if (!key) throw new Error("A chave do Resend não está configurada no painel.");
    const res = await fetch("https://api.resend.com/emails", {
      method: "POST",
      headers: { "Content-Type": "application/json", Authorization: `Bearer ${key}` },
      body: JSON.stringify({
        from: data.from,
        to: [data.to],
        subject: data.subject,
        ...(data.html ? { html: data.html } : { text: data.text ?? "" }),
      }),
    });
    const body = (await res.json().catch(() => ({}))) as { id?: string; message?: string };
    if (!res.ok) throw new Error(body.message || `Resend HTTP ${res.status}`);
    return { id: body.id ?? null };
  });
