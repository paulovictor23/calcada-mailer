# Resend Mailer

Crie uma ferramenta de disparo de e-mail marketing simples e funcional utilizando React, Vite, Tailwind CSS e a API do Resend.

Funcionalidades Principais:

Configuração de Credenciais: Um campo de input para inserir a API Key do Resend (salvando apenas no estado local da aplicação para segurança).

Editor de E-mail: Campos para 'E-mail do Remetente' (deve seguir o domínio verificado no Resend), 'Assunto' e um campo de texto (Textarea) para o 'Corpo do E-mail' (suporte a HTML seria ideal).

Gestão de Destinatários: Um campo para colar uma lista de e-mails separados por vírgula ou um e-mail por linha.

Log de Envios: Uma área abaixo do formulário que mostre o status de cada envio (Enviando... / Sucesso / Erro).

Especificações Técnicas:

Utilize a biblioteca oficial do Resend (resend) ou faça as requisições via fetch para o endpoint de e-mail deles.

Implemente um sistema de debounce ou um pequeno intervalo entre os envios para evitar bloqueios, caso a lista seja grande.

O design deve ser limpo, moderno e responsivo, focado em produtividade.

Adicione validação de e-mail básica antes de permitir o disparo.

This project was built with [Lovable](https://lovable.dev).

**Live app**: https://pure-reach-mail.lovable.app

## Build with Lovable

Continue developing this project in the [Lovable editor](https://lovable.dev/projects/5c12dac4-dfc3-4d55-b243-290a005b3ad8).

- **Ship faster**: describe what you want to build and Lovable handles the code.
- **Stay in sync**: every change made in Lovable is committed straight to this repository.
- **Full ownership**: this code is yours. Push to `main` on GitHub and your changes sync back into Lovable, ready for your next prompt.

## Development

Prefer working locally? You need Node.js and npm — [install with nvm](https://github.com/nvm-sh/nvm#installing-and-updating).

```sh
git clone <this-repository-url>
cd <repository-name>
npm i
npm run dev
```
